// Lambda ANAPEC → Monday.com - Multi-sociétés v6
// Nouveaux board IDs + Etat ANAPEC en texte
import https from 'https';

const MONDAY_API_KEY = process.env.MONDAY_API_KEY;

// Nouveaux Board IDs (recréés avec colonnes unifiées)
const BOARD_MAP = {
  'GRUPO_TEYEZ':    process.env.BOARD_GRUPO_TEYEZ   || '5094533264',
  'SIGARMOR':       process.env.BOARD_SIGARMOR       || '5094533195',
  'EIM':            process.env.BOARD_EIM            || '5094406986',
  'KIRKOS':         process.env.BOARD_KIRKOS         || '5094533165',
  'KIRKOS_GUARD':   process.env.BOARD_KIRKOS_GUARD   || '5094532891',
  'NEISS':          process.env.BOARD_NEISS          || '5094532791',
  'NORIA_BIANCA':   process.env.BOARD_NORIA_BIANCA   || '5094532861',
  'CQ_SERVICE':     process.env.BOARD_CQ_SERVICE     || '5094533129',
  'ANAPEC_GLOBAL':  process.env.BOARD_GLOBAL         || '5094534887',
};

// IDs colonnes (identiques sur tous les nouveaux boards)
const COL = {
  ref:        'text_mm25bmx6',   // N° contrat ANAPEC
  etat:       'text_mm2cq9p4',   // Etat ANAPEC — TYPE TEXT (texte exact ANAPEC)
  type:       'text_mm25cnhq',   // Type contrat
  date_sig:   'date_mm25j55f',   // Date signature
  date_fin:   'date_mm25dgst',   // Date fin
  agence:     'text_mm255qz2',   // Agence ANAPEC
  nom_entrep: 'text_mm25b5td',   // Nom entreprise
  secteur:    'text_mm25anzf',   // Secteur activité
  adresse:    'text_mm25sj8x',   // Adresse entreprise
  telephone:  'phone_mm25494m',  // Téléphone
  cnss_empl:  'text_mm25pz5s',   // CNSS employeur
  rc:         'text_mm25qwwm',   // RC
  forme_jur:  'text_mm25c1zg',   // Forme juridique
  nom_agent:  'text_mm256r65',   // Nom agent
  prenom:     'text_mm25rm0q',   // Prénom agent
  nationalite:'text_mm257ne0',   // Nationalité
  cin:        'text_mm25ycje',   // CIN
  cnss_agent: 'text_mm25vspv',   // N° CNSS agent
  niveau:     'text_mm25dcs7',   // Niveau scolaire
  poste:      'text_mm25x2aw',   // Poste
  duree:      'numeric_mm25fr45',// Durée (mois)
  salaire:    'numeric_mm25aj7f',// Salaire (DH)
  cnss_trait: 'color_mm253wpv',  // Traitement CNSS
  email_soc:  'text_mm25cb1c',   // Email société
};

function mondayQuery(query) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({ query });
    const req = https.request({
      hostname: 'api.monday.com',
      path: '/v2',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': MONDAY_API_KEY,
        'API-Version': '2024-01',
        'Content-Length': Buffer.byteLength(body)
      }
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch(e) { reject(new Error('JSON parse: ' + data.substring(0,200))); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

async function getMondayItems(boardId) {
  const data = await mondayQuery(`{
    boards(ids: ${boardId}) {
      items_page(limit: 500) {
        items { id name column_values { id text } }
      }
    }
  }`);
  return data.data?.boards?.[0]?.items_page?.items || [];
}

async function createItem(boardId, groupId, name, cv) {
  const s = JSON.stringify(JSON.stringify(cv));
  return mondayQuery(`mutation {
    create_item(board_id: ${boardId}, group_id: "${groupId}",
    item_name: "${name.replace(/"/g,'')}",
    column_values: ${s}) { id }
  }`);
}

async function updateItem(boardId, itemId, cv) {
  const s = JSON.stringify(JSON.stringify(cv));
  return mondayQuery(`mutation {
    change_multiple_column_values(board_id: ${boardId},
    item_id: ${itemId}, column_values: ${s}) { id }
  }`);
}

function buildCV(contract) {
  const cv = {};
  const set    = (col, val) => { if (val?.toString().trim()) cv[col] = val.toString().trim(); };
  const setNum = (col, val) => {
    const n = parseFloat(String(val||'').replace(/[^\d.]/g,''));
    if (!isNaN(n) && n > 0) cv[col] = n;
  };
  const setDate = (col, val) => {
    if (!val || val === '---' || val === '-') return;
    const p = String(val).split('/');
    if (p.length === 3) cv[col] = { date: `${p[2]}-${p[1]}-${p[0]}` };
  };

  set(COL.ref,         contract.ref);
  set(COL.type,        contract.type);
  set(COL.cin,         contract.cin);
  setDate(COL.date_sig, contract.date_sig);
  setDate(COL.date_fin, contract.date_fin);
  set(COL.agence,      contract.agence);
  set(COL.nom_entrep,  contract.nom_entrep);
  set(COL.secteur,     contract.secteur);
  set(COL.adresse,     contract.adresse);
  set(COL.rc,          contract.rc);
  set(COL.cnss_empl,   contract.cnss_empl);
  set(COL.forme_jur,   contract.forme_jur);
  set(COL.nom_agent,   contract.nom_agent);
  set(COL.prenom,      contract.prenom);
  set(COL.nationalite, contract.nationalite);
  set(COL.cnss_agent,  contract.cnss_agent);
  set(COL.niveau,      contract.niveau);
  set(COL.poste,       contract.poste);
  setNum(COL.duree,    contract.duree);
  setNum(COL.salaire,  contract.salaire);

  if (contract.telephone) {
    const tel = String(contract.telephone).replace(/[^\d]/g,'').substring(0,10);
    if (tel.length >= 9) cv[COL.telephone] = { phone: tel, countryShortName: 'MA' };
  }

  // Etat ANAPEC : texte exact ("Validé & Signé", "En cours", "Projet")
  if (contract.etat?.trim()) {
    cv[COL.etat] = contract.etat.trim();
  }

  return cv;
}

export const handler = async (event) => {
  console.log('=== Lambda ANAPEC → Monday v6 ===');
  try {
    let body;
    if (event.body) {
      body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
    } else {
      body = event;
    }

    const contracts = body.contracts || [];
    const societe   = body.societe   || 'GRUPO_TEYEZ';
    console.log(`Société: ${societe} | ${contracts.length} contrats`);

    if (contracts.length === 0) {
      return {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ message: 'Aucun contrat', stats: { total: 0 } })
      };
    }

    const boardId = BOARD_MAP[societe];
    if (!boardId) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: `Société inconnue: ${societe}. Dispo: ${Object.keys(BOARD_MAP).join(', ')}` })
      };
    }

    console.log(`Board: ${boardId}`);
    const items = await getMondayItems(boardId);
    const itemByRef = {}, itemByName = {};
    items.forEach(item => {
      itemByName[item.name] = item.id;
      itemByName[item.name.replace('/1','').replace('/','')] = item.id;
      const refCol = item.column_values.find(c => c.id === COL.ref);
      if (refCol?.text) {
        itemByRef[refCol.text] = item.id;
        itemByRef[refCol.text.replace('/1','').replace('/','')] = item.id;
      }
    });

    console.log(`${items.length} items existants`);
    let created = 0, updated = 0, errors = 0;

    for (const contract of contracts) {
      const ref    = contract.ref || '';
      const etatLow = (contract.etat || '').toLowerCase();
      // EN COURS = Validé/Signé/Fait → group topics
      // PROJET   = En cours/Projet   → group group_title
      const isProjet = etatLow.includes('projet') || etatLow.includes('en cours') || etatLow.includes('cours');
      const groupId  = isProjet ? 'group_title' : 'topics';
      const cv = buildCV(contract);
      const existingId = itemByRef[ref] || itemByName[ref];

      try {
        if (existingId) {
          await updateItem(boardId, existingId, cv);
          updated++;
        } else {
          await createItem(boardId, groupId, ref, cv);
          created++;
        }
        await new Promise(r => setTimeout(r, 300));
      } catch(e) {
        console.log(`✗ ${ref}: ${e.message}`);
        errors++;
      }
    }

    const stats = { total: contracts.length, created, updated, errors, societe };
    console.log(`=== FIN: ${JSON.stringify(stats)} ===`);
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ message: 'OK', stats })
    };

  } catch(error) {
    console.error('Erreur:', error);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
